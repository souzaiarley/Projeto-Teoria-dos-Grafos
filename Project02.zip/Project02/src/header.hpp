/* General purposes */
#include <iostream>
#include <vector>

/* Reading files */
#include <fstream>
#include <sstream>

/* Building graphs */
#include <map>
#include <list>

/* Search */
#include <queue>
#include <stack>

using namespace std;
